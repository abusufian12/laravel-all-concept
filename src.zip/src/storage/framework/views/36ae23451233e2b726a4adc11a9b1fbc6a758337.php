

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Posts')); ?></div>

                <div class="card-body">
                    <table class="table table-bordered table-hover">
                    <thead>
                        <tr class="text-center" style="background: #d1d1d1">
                            <th width="2%">S/L</th>
                            <th width="10%">Title</th>
                            <th width="10%">Description</th>
                            <th width="10%">Excerpt</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td class="pt-5"><?php echo e($key+1); ?></td>
                            <td class="pt-50"><?php echo e($post->title); ?></td>
                            <td class="pt-50"><?php echo e($post->description); ?></td>
                            <td class="pt-50"><?php echo e($post->excerpt); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\installed_soft\xampp8\htdocs\laravel-all-concept\resources\views/posts/index.blade.php ENDPATH**/ ?>